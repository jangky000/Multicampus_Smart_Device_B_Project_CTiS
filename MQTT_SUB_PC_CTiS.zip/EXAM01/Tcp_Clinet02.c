#pragma comment(lib,"ws2_32")
#pragma warning(disable: 4996)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <conio.h>
#include <windows.h>

#include "libemqtt.h"


#define BUF_SIZE	512
#define	SEVER_IP	"192.168.0.200"
#define PORT		1883

#define BATTERY 100
#define STOPTIME 9
////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct _CAR
{
	int y;
	int x;

	int id;
	int lane; // �ٱ� 1, �� 2. 
	int vel; // �Ⱥ����� ��.

	int battery;
	int cost;
	int accident_flag;
	int accident_num;

	int home_flag;

	int drive_distance;

} CAR;

//lane1: 1~15 -> 8~120
//lane2: 3-13 -> 24~104
CAR car_arr[5] = {	{ 1,	7,	1, 1, 2, BATTERY, 0, 0, 0, 0, 0 },
					{ 13,	7,	2, 2, 1, BATTERY, 0, 0, 0, 0, 0 },
					{ 15,	1,	3, 1, 2, BATTERY, 0, 0, 0, 0, 0 },
					{ 15,	15,	4, 1, 1, BATTERY, 0, 0, 0, 0, 0 },
					{ 3,	7,	5, 2, 2, BATTERY, 0, 0, 5, 0, 0 } };

int honk[5] = { 0, };
int prev[5] = { 1, 1, 1, 1, 1 };
int origin_vel[5];

void Origin_Vel_Init()
{
	int i;
	for (i = 0; i < 5; i++)
	{
		origin_vel[i] = car_arr[i].vel;
	}
}

//look-up table (LUT)
int Car_Dir[16][16][2];
void Car_Dir_init()
{
	int i = 0;


	//1�� ����
	for (i = 0; i < 14; i++)
	{
		//���������� �̵�
		Car_Dir[1][1 + i][0] = 0; // y����
		Car_Dir[1][1 + i][1] = 1; // x����
	}
	for (i = 0; i < 14; i++)
	{
		//�Ʒ������� �̵�
		Car_Dir[1 + i][15][0] = 1; // y����
		Car_Dir[1 + i][15][1] = 0; // x����
	}
	for (i = 0; i < 14; i++)
	{
		//�������� �̵�
		Car_Dir[15][15 - i][0] = 0; // y����
		Car_Dir[15][15 - i][1] = -1; // x����
	}
	for (i = 0; i < 14; i++)
	{
		//�������� �̵�
		Car_Dir[15 - i][1][0] = -1; // y����
		Car_Dir[15 - i][1][1] = 0; // x����
	}

	//2�� ����
	for (i = 0; i < 10; i++)
	{
		//���������� �̵�
		Car_Dir[3][3 + i][0] = 0; // y����
		Car_Dir[3][3 + i][1] = 1; // x����
	}
	for (i = 0; i < 10; i++)
	{
		//�Ʒ������� �̵�
		Car_Dir[3 + i][13][0] = 1; // y����
		Car_Dir[3 + i][13][1] = 0; // x����
	}
	for (i = 0; i < 10; i++)
	{
		//�������� �̵�
		Car_Dir[13][13 - i][0] = 0; // y����
		Car_Dir[13][13 - i][1] = -1; // x����
	}
	for (i = 0; i < 10; i++)
	{
		//�������� �̵�
		Car_Dir[13 - i][3][0] = -1; // y����
		Car_Dir[13 - i][3][1] = 0; // x����
	}
}

//��� ���
void Cal_Cost(int i)
{
	static int prev[5] = {0, };

	if ((car_arr[i].y == 9 || car_arr[i].y == 10) && car_arr[i].x == 3) {
		//if (car_arr[i].vel == 2)
		if (car_arr[i].vel != 0)
			prev[i] = car_arr[i].vel;
		else
			prev[i] = 1;

		car_arr[i].vel = 1;
	}
	else if (car_arr[i].y == 8 && car_arr[i].x == 3) {
		car_arr[i].cost += 1000;
		printf("%d�� ���� ��� + 1,000, �հ�: %d\n", i, car_arr[i].cost);
	}
	else if (car_arr[i].y == 7 && car_arr[i].x == 3)
	{
		//if (prev[i] == 2)
		car_arr[i].vel = prev[i];
	}
}
enum Direct{LEFT, RIGHT};

void Parallel_Move(int car, int lane)
{
	if (lane == 1)
	{
		if (car_arr[car].y == 1 && car_arr[car].x >= 3 && car_arr[car].x <= 13) {
			car_arr[car].y = 3;
			car_arr[car].lane = 2;
		}
		else if (car_arr[car].x == 15 && car_arr[car].y >= 3 && car_arr[car].y <= 13) {
			car_arr[car].x = 13;
			car_arr[car].lane = 2;
		}
		else if (car_arr[car].y == 15 && car_arr[car].x >= 3 && car_arr[car].x <= 13) {
			car_arr[car].y = 13;
			car_arr[car].lane = 2;
		}
		else if (car_arr[car].x == 1 && car_arr[car].y >= 3 && car_arr[car].y <= 13) {
			car_arr[car].x = 3;
			car_arr[car].lane = 2;
		}
	}
	else if (lane == 2)
	{
		if (car_arr[car].y == 3 && car_arr[car].x >= 3 && car_arr[car].x <= 13)
			car_arr[car].y = 1;
		else if (car_arr[car].x == 13 && car_arr[car].y >= 3 && car_arr[car].y <= 13)
			car_arr[car].x = 15;
		else if (car_arr[car].y == 13 && car_arr[car].x >= 3 && car_arr[car].x <= 13)
			car_arr[car].y = 15;
		else if (car_arr[car].x == 3 && car_arr[car].y >= 3 && car_arr[car].y <= 13)
			car_arr[car].x = 1;

		car_arr[car].lane = 1;
	}
	//if(car_arr[car].y )
}

//���� ����
void Change_Lane(int i, int dir)
{
	switch (dir)
	{
	case LEFT:
		if (car_arr[i].lane == 1) {
			honk[i] = 1; // ����
		}
		else{
			//���� ���� �ִ��� Ȯ��
			//car_arr[i].lane = 1;
			Parallel_Move(i, 2);
		}
		break;

	case RIGHT:
		if (car_arr[i].lane == 2) {
			honk[i] = 1; // ����
		}
		else {
			//���� ���� �ִ��� Ȯ��
			//car_arr[i].lane = 2;
			Parallel_Move(i, 1);
		}
		break;
	}
}

int hdis[2];

//������ �Ÿ� ���
void Home_Dist()
{
	int i;	
	for (i = 0; i < 2; i++)
	{
		//hdis[i] = 0;
		if (car_arr[i].home_flag == 1)
		{
			if (car_arr[i].lane == 1)//1�� ����
			{
				if (car_arr[i].y == 1 && car_arr[i].x >= 1 && car_arr[i].x <= 15) //����
				{
					hdis[i] = 15 - car_arr[i].x + 4 + 3;
				}
				else if (car_arr[i].x == 15 && car_arr[i].y >= 1 && car_arr[i].y <= 15) //������
				{
					if (car_arr[i].y <= 5) hdis[i] = 5 - car_arr[i].y + 3; //�ٷ� �� �� �ִ� ��ġ
					else hdis[i] = 15 - car_arr[i].y + 14 + 14 + 14 + 4 + 3; //���Ƽ� ���ߵǴ� ��ġ
				}
				else if (car_arr[i].y == 15 && car_arr[i].x >= 1 && car_arr[i].x <= 15) //�Ʒ�
				{
					hdis[i] = car_arr[i].x - 1 + 14 + 14 + 4 + 3;
				}
				else if (car_arr[i].x == 1 && car_arr[i].y >= 1 && car_arr[i].y <= 15) //����
				{
					hdis[i] = car_arr[i].y - 1 + 14 + 4 + 3;
				}
				else if (car_arr[i].y == 5 && car_arr[i].x >= 15) //���� ���� ��
				{
					hdis[i] = 18 - car_arr[i].x; //������ ���߱� ������ 0�� �ȳ��� �� ������.
				}
			}
			else if (car_arr[i].lane == 2) //2�� ���� 
			{
				if (car_arr[i].y == 3 && car_arr[i].x >= 3 && car_arr[i].x <= 13) //����
				{
					hdis[i] = 13 - car_arr[i].x + 2 + 5;
				}
				else if (car_arr[i].x == 13 && car_arr[i].y >= 3 && car_arr[i].y <= 13) //������
				{
					if (car_arr[i].y <= 5) hdis[i] = 5 - car_arr[i].y + 5; //�ٷ� �� �� �ִ� ��ġ
					else hdis[i] = 13 - car_arr[i].y + 10 + 10 + 10 + 2 + 5; //���Ƽ� ���ߵǴ� ��ġ
				}
				else if (car_arr[i].y == 13 && car_arr[i].x >= 3 && car_arr[i].x <= 13) //�Ʒ�
				{
					hdis[i] = car_arr[i].x - 3 + 10 + 10 + 2 + 5;
				}
				else if (car_arr[i].x == 3 && car_arr[i].y >= 3 && car_arr[i].y <= 13) //����
				{
					hdis[i] = car_arr[i].y - 3 + 10 + 2 + 5;
				}
				else if (car_arr[i].y == 5 && car_arr[i].x >= 13) //���� ���� ��
				{
					hdis[i] = 18 - car_arr[i].x;
				}
			}
			//printf("%d\n", hdis[i]-1);
			hdis[i]--;
		}
	}
}


void Accident_Handler()
{
	static int time[2] = { STOPTIME, STOPTIME };
	static int prev[2] = { 0, };

	//��� ó��
	if (car_arr[0].battery < 0)
	{
		prev[0] = car_arr[0].vel;
		printf("prev1 = %d\n", prev[0]);
		car_arr[0].vel = 0;
		car_arr[0].accident_flag = 1;
		car_arr[0].accident_num++;
		car_arr[0].battery = 0;
	}
	else if (car_arr[1].battery < 0)
	{
		prev[1] = car_arr[1].vel;
		printf("prev2 = %d\n", prev[1]);
		car_arr[1].vel = 0;
		car_arr[1].accident_flag = 1;
		car_arr[1].accident_num++;
		car_arr[1].battery = 0;
	}

	//������
	if (car_arr[0].accident_flag == 1)
	{
		printf("time1 %d\n", time[0]);
		time[0]--;
		if (time[0] < 0) {
			car_arr[0].accident_flag = 0;
			time[0] = STOPTIME;
			car_arr[0].vel = prev[0];
			car_arr[0].battery = BATTERY;
			printf("load prev1 = %d\n", prev[0]);
		}
	}
	else if (car_arr[1].accident_flag == 1)
	{
		printf("time2 %d\n", time[1]);
		time[1]--;
		if (time[1] < 0) {
			car_arr[1].accident_flag = 0;
			time[1] = STOPTIME;
			car_arr[1].vel = prev[1];
			car_arr[1].battery = BATTERY;
			printf("load prev2 = %d\n", prev[1]);
		}
	}
}

volatile int safe_yx[2];

void Safe_Distance(int y, int x, int n)
{
	if (n == 0) {
		safe_yx[0] = y;
		safe_yx[1] = x;
		return;
	}
	//printf("%d ", n);
	Safe_Distance(y+Car_Dir[y][x][0], x+Car_Dir[y][x][1], n - 1);
}

void Keep_Distance()
{
	int i,j;
	//static prev[5] = {0, };
	//static origin_vel[5] = {1, 1, 1, 1, 1};

	// ���� �Ÿ� ���
	safe_yx[0] = 0;
	safe_yx[1] = 0;

	for (i = 0; i < 5; i++)
	{
		//if (origin_vel[i] == 1 && car_arr[i].vel == 1) continue;

		safe_yx[0] = 0;
		safe_yx[1] = 0;

		Safe_Distance(car_arr[i].y, car_arr[i].x, 4); // 2�϶� �ٱ� ���� �ν� ����, 3�϶� ���� ���� �ν� ����

		for (j = 0; j < 5; j++)
		{
			if (i == j) continue;
			if (car_arr[i].lane != car_arr[j].lane) continue;

			if (car_arr[j].y == safe_yx[0] && car_arr[j].x == safe_yx[1])
			{
				if (i == 0) {
					//printf("1111111111111111111111111111111111111��Ȯ�� �Ÿ� ���濡 %d�� ���� �ν� ��� ��ǥ: %d %d \n", j, car_arr[3].y, car_arr[3].x);
					//printf("�� ��ǥ: %d %d // ���� ��ǥ: %d %d \n", car_arr[i].y, car_arr[i].x, safe_yx[0], safe_yx[1]);
					//printf("3�� �ӵ� %d \n", car_arr[3].vel);
				}
				if (car_arr[i].vel > car_arr[j].vel) { //�� ���� �ӵ��� �� ���� ��
					//if(i == 0)
						//printf("555555555555555555555555555555555  %d�� ����, ������ %d \n", i, j);
					honk[i] = 1;
					//if(car_arr[i].vel > 1)
					//	origin_vel[i] = car_arr[i].vel;
				}
				else
					honk[i] = -1;
				
				if(car_arr[i].battery != 0 && car_arr[i].vel > car_arr[j].vel) // ����j�� �ӵ��� �� �����ٸ�
					car_arr[i].vel = car_arr[j].vel;

				//if (i == 2)
				//	printf("���濡 %d�� ���� �ν�", j);
				//break;
			}
			else if ((car_arr[i].y - car_arr[j].y)*(safe_yx[0] - car_arr[j].y) <= 0 && (car_arr[i].x - car_arr[j].x)*(safe_yx[1] - car_arr[j].x) <= 0)
			{
				//origin_vel[i] = car_arr[i].vel;
				//if (i == 0)
				//	printf("2222222222222222222222222���� �� ���濡 %d�� ���� �ν�\n", j);

				honk[i] = -1;
				//if (car_arr[i].vel != 0) // ���� �ӵ��� 0�� �ƴҶ�
				//	origin_vel[i] = car_arr[i].vel;

				car_arr[i].vel = 0;
			}
			else
			{
				if (i == 0) {
					//printf("33333333333333333333333333�� ���濡 %d�� ���� �ν� �ӵ�: %d ��� ��ǥ: %d %d \n", j, car_arr[3].vel, car_arr[3].y, car_arr[3].x);
					//printf("�� ��ǥ: %d %d // ���� ��ǥ: %d %d \n", car_arr[i].y, car_arr[i].x, safe_yx[0], safe_yx[1]);
					//printf("���� �ӵ� 1��: %d 2��: %d 3��: %d 4��: %d 5��:%d \n", origin_vel[0], origin_vel[1], origin_vel[2], origin_vel[3], origin_vel[4]);
				}
			}
		}
		//printf("honk: %d, origin_vel: %d, battery: %d\n", honk[0], origin_vel[0], car_arr[0].battery);
		if (honk[i] == 0 && origin_vel[i] != 0 && car_arr[i].battery != 0) {
			//printf("666666666666666666666666666666666     %d ���� �ӵ� %d\n", i, origin_vel[i]);
			if (car_arr[i].home_flag == 1)
				continue;
			//printf("44444444444444444444444444444444444444444444444444444444\n");
			if (car_arr[i].vel < origin_vel[i]) {
				printf("%d �� ���� �ӵ� ����\n", i);
				car_arr[i].vel = origin_vel[i];
			}
		}
	}
}

void Traffic_Update()
{
	int i, j, dis = 0;

	for (i = 0; i < 5; i++) //5���� ���� ���ؼ� ��ġ�� �ٲ��ش�. ���� ��ġ�� �������� �̵��� ��ġ*�ӵ��� ������.
	{
		if (car_arr[i].home_flag == 1 && car_arr[i].y == 5 && car_arr[i].x >= 13)
		{
			if (car_arr[i].x == 17) {
				car_arr[i].vel = 0; // ���� ����
				if(car_arr[i].battery < 100)
					car_arr[i].battery++;
			}
			else {
				car_arr[i].x += 1;
				car_arr[i].drive_distance += 1;
			}
		}
		else if (car_arr[i].home_flag == 2 )
		{
			//������ ����
			if (car_arr[i].lane == 1)
			{
				if (car_arr[i].x == 15)
				{
					car_arr[i].vel = 2;
					car_arr[i].home_flag = 0;
				}
				else {
					car_arr[i].x -= 1;
					car_arr[i].drive_distance += 1;
				}
			}
			else if (car_arr[i].lane == 2)
			{
				if(car_arr[i].x == 13)
				{
					car_arr[i].vel = 2;
					car_arr[i].home_flag = 0;
				}
				else {
					car_arr[i].x -= 1;
					car_arr[i].drive_distance += 1;
				}
			}
		}
		else {
			if (car_arr[i].home_flag == 1 && (car_arr[i].y == 3 || car_arr[i].y == 4) && car_arr[i].x >= 13)
				car_arr[i].vel = 1;
			else
				Cal_Cost(i);

			//���� �������ش�.
			safe_yx[0] = 0;
			safe_yx[1] = 0;
			Safe_Distance(car_arr[i].y, car_arr[i].x, car_arr[i].vel);
			car_arr[i].y = safe_yx[0];
			car_arr[i].x = safe_yx[1];
			//car_arr[i].x += (Car_Dir[car_arr[i].y][car_arr[i].x][1] * car_arr[i].vel);

			car_arr[i].battery -= car_arr[i].vel;
			car_arr[i].drive_distance += car_arr[i].vel;
		}
	}

	//printf("%d%%\n", car_arr[0].battery);
	Accident_Handler();

	Keep_Distance();

	/*
	// �����غ��� lut�� �Ƚᵵ �� �� ���Ƽ� �׳� �ٸ��� Ǯ����.
	for (i = 0; i < 5; i++) //5���� ������ ���� �ٸ� ���� ���ؼ�
		for (j = 0; j < 5; j++)
		{
			if (i == j) continue; //������ �� �� �ʿ� ����.
			if (car_arr[i].lane == car_arr[j].lane) //������ lane�� �޸��� �ִٸ� ==��������� ���� �ϸ� �� �� ����
			{

				if (car_arr[i].vel == 0 || car_arr[j].vel == 0)
					continue;

				if (car_arr[i].y <= car_arr[j].y && car_arr[i].x > car_arr[j].x)
				{
					//�Ÿ��� 4���� �۴ٸ�
					if (car_arr[j].y - car_arr[i].y + car_arr[i].x - car_arr[j].x < 5)
					{
						if (car_arr[i].vel != car_arr[j].vel)
							honk[i] = 1;
						car_arr[i].vel = 1;
					}
				}
				else if (car_arr[i].y > car_arr[j].y && car_arr[i].x >= car_arr[j].x)
				{
					if (car_arr[i].y - car_arr[j].y + car_arr[i].x - car_arr[j].x < 5)
					{
						if (car_arr[i].vel != car_arr[j].vel)
							honk[i] = 1;
						car_arr[i].vel = 1;
					}
					
				}
				else if (car_arr[i].y >= car_arr[j].y && car_arr[i].x < car_arr[j].x)
				{
					if (car_arr[i].y - car_arr[j].y + car_arr[j].x - car_arr[i].x < 5)
					{
						if (car_arr[i].vel != car_arr[j].vel)
							honk[i] = 1;
						car_arr[i].vel = 1; 
					}
					
				}
				else if (car_arr[i].y < car_arr[j].y && car_arr[i].x <= car_arr[j].x)
				{
					if (car_arr[j].y - car_arr[i].y + car_arr[j].x - car_arr[i].x < 5)
					{
						if (car_arr[i].vel != car_arr[j].vel)
							honk[i] = 1;
						car_arr[i].vel = 1; 
					}
				}
				
			}
		}
		*/

	Home_Dist();
}

////////////////////////////////////////////////////////////////////////////////////////////////



//	�����Լ� ������� �� ����
void Error_Exit(char* str)
{
	printf("%s Error!! Exit...\n",str);
	_getch();
	exit(1);
}


#define RCVBUFSIZE 1024
uint8_t packet_buffer[RCVBUFSIZE];

int socket_id;
SOCKET hSocket;



int send_packet(void* socket_info, const void* buf, unsigned int count)
{
	SOCKET fd = *((SOCKET*)socket_info);
	return send(fd, buf, count, 0);
}

int init_socket(mqtt_broker_handle_t* broker, const char* hostname, short port)
{
	int flag = 1;
	int keepalive = 300; // Seconds

	WSADATA wsaData;
	SOCKADDR_IN servAdr;

	//	���� �ʱ�ȭ
	if(WSAStartup(MAKEWORD(2, 2), &wsaData)!=0)
	{
		Error_Exit("WSAStartup()"); 
	}

	//	���� ����: socket()
	hSocket=socket(PF_INET, SOCK_STREAM, 0);
	if(hSocket==INVALID_SOCKET)
	{
		Error_Exit("socket()");
	}
	

	//	������ �ʱ�ȭ �� connect()
	printf("try to connect to the server...");
	memset(&servAdr, 0, sizeof(servAdr));
	servAdr.sin_family=AF_INET;
	servAdr.sin_addr.s_addr=inet_addr(hostname);
	servAdr.sin_port=htons(port);
	
	if(connect(hSocket, (SOCKADDR*)&servAdr, sizeof(servAdr))==SOCKET_ERROR)
	{
		Error_Exit("connect()");
	}
	printf("\nserver connected...\n");
	printf("[send]: ");

	// MQTT stuffs
	mqtt_set_alive(broker, keepalive);
	broker->socket_info = (void*)&hSocket;
	broker->send = send_packet;

	return 0;
}

int close_socket(mqtt_broker_handle_t* broker)
{
	SOCKET fd = *((SOCKET*)broker->socket_info);
	closesocket(fd);
	return WSACleanup();
}


int read_packet(int timeout)
{
	int total_bytes = 0, bytes_rcvd, packet_length;

	memset(packet_buffer, 0, sizeof(packet_buffer));

	while(total_bytes < 2) // Reading fixed header
	{
		if((bytes_rcvd = recv(hSocket, (packet_buffer+total_bytes), RCVBUFSIZE, 0)) <= 0)
			return -1;
		total_bytes += bytes_rcvd; // Keep tally of total bytes

	}

	packet_length = packet_buffer[1] + 2; // Remaining length + fixed header length
	while(total_bytes < packet_length) // Reading the packet
	{
		if((bytes_rcvd = recv(hSocket, (packet_buffer+total_bytes), RCVBUFSIZE, 0)) <= 0)
			return -1;
		total_bytes += bytes_rcvd; // Keep tally of total bytes
	}
	printf("total byte:  %d\n", total_bytes);
	return packet_length;
}

int main(void)
{
	int i;
	unsigned long nonBlk = 1; //�ͺ��� �Ӽ�
	char buf[100]; //�ۺ�����

	int packet_length;
	uint16_t msg_id, msg_id_rcv;
	uint16_t msg_id2;
	mqtt_broker_handle_t broker;

	mqtt_init(&broker, "Ctis");
	mqtt_init_auth(&broker, NULL, NULL);
	init_socket(&broker, SEVER_IP, PORT);

	// >>>>> CONNECT
	mqtt_connect(&broker);

	// <<<<< CONNACK
	packet_length = read_packet(0);

	printf("receive packet length = %d\n",packet_length);

	if(packet_length < 0)
	{
		fprintf(stderr, "Error(%d) on read packet!\n", packet_length);
		return -1;
	}

	if(MQTTParseMessageType(packet_buffer) != MQTT_MSG_CONNACK)
	{
		fprintf(stderr, "CONNACK expected!\n");
		return -2;
	}

	if(packet_buffer[3] != 0x00)
	{
		fprintf(stderr, "CONNACK failed!\n");
		return -2;
	}

	printf("CONNACK received..\n");

	// >>>>> PUBLISH QoS 0
	printf("subscribe\n");
	mqtt_subscribe(&broker, "sensor/+/+", &msg_id);

	// <<<<< SUBACK
	packet_length = read_packet(1);
	if(packet_length < 0)
	{
		fprintf(stderr, "Error(%d) on read packet!\n", packet_length);
		return -1;
	}

	if(MQTTParseMessageType(packet_buffer) != MQTT_MSG_SUBACK)
	{
		fprintf(stderr, "SUBACK expected!\n");
		return -2;
	}

	msg_id_rcv = mqtt_parse_msg_id(packet_buffer);
	if(msg_id != msg_id_rcv)
	{
		fprintf(stderr, "%d message id was expected, but %d message id was found!\n", msg_id, msg_id_rcv);
		return -3;
	}

	//�ͺ��� ����
	if (ioctlsocket(hSocket, FIONBIO, &nonBlk)) Error_Exit("NonBlock");

	//Look-Up ���̺� �ʱ�ȭ
	Car_Dir_init();
	//�ʱ� �ӵ��� ����
	Origin_Vel_Init();

	memset(buf, 0, sizeof(buf));
	sprintf(buf, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d ", car_arr[0].y, car_arr[0].x, car_arr[1].y, car_arr[1].x, car_arr[2].y, car_arr[2].x, car_arr[3].y, car_arr[3].x, car_arr[4].y, car_arr[4].x, honk[0], honk[1], car_arr[0].battery, car_arr[1].battery);
	printf("%s\n", buf);
	mqtt_publish(&broker, "traffic", buf, 0);
	memset(honk, 0, sizeof(honk));

	for(;;)
	{
		Sleep(500);
		Traffic_Update();
		
		//�߽�(�ڵ��� ����)
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d ", car_arr[0].y, car_arr[0].x, car_arr[1].y, car_arr[1].x, car_arr[2].y, car_arr[2].x, car_arr[3].y, car_arr[3].x, car_arr[4].y, car_arr[4].x, honk[0], honk[1], car_arr[0].battery, car_arr[1].battery);
		//printf("%s\n", buf);
		mqtt_publish(&broker, "traffic", buf, 0);
		memset(honk, 0, sizeof(honk));

		//�߽�(�� ����)
		if(car_arr[0].vel == 0 || car_arr[1].vel == 0 || hdis[0] || hdis[1] )
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ", 
			car_arr[0].accident_flag, hdis[0], car_arr[0].vel, car_arr[0].cost, car_arr[0].battery, car_arr[0].accident_num, car_arr[0].drive_distance, car_arr[0].y, car_arr[0].x,
			car_arr[1].accident_flag, hdis[1], car_arr[1].vel, car_arr[1].cost, car_arr[1].battery, car_arr[1].accident_num, car_arr[1].drive_distance, car_arr[1].y, car_arr[1].x );
		printf("%s\n", buf);
		mqtt_publish(&broker, "home", buf, 0);

		//����
		// <<<<<
		packet_length = read_packet(0);
		printf("%d", packet_length);
		if(packet_length == -1)
		{
			//fprintf(stderr, "Error(%d) on read packet!\n", packet_length);
			//return -1;
		}
		else if(packet_length > 0)
		{
			printf("Packet Header: 0x%x...\n", packet_buffer[0]);
			if(MQTTParseMessageType(packet_buffer) == MQTT_MSG_PUBLISH)
			{
				//�Ľ�
				uint8_t topic[255], msg[1000];
				uint16_t len;
				//����
				len = mqtt_parse_pub_topic(packet_buffer, topic);
				topic[len] = '\0'; // for printf
				//�޽���
				len = mqtt_parse_publish_msg(packet_buffer, msg);
				msg[len] = '\0'; // for printf
				printf("%s %s\n", topic, msg);

				//��1
				if (strcmp(topic, "sensor/1/4") == 0) {
					if(car_arr[0].home_flag == 1)
						car_arr[0].home_flag = 2; // ������ ������ ����
					else 
						car_arr[0].home_flag = 1;
				}
				else if (strcmp(topic, "sensor/1/1") == 0)
					Change_Lane(0, LEFT);
				else if (strcmp(topic, "sensor/1/2") == 0)
					Change_Lane(0, RIGHT);
				else if (strcmp(topic, "sensor/1/gyro") == 0)
					car_arr[0].battery = 0;
				
				//��2
				if (strcmp(topic, "sensor/2/4") == 0) {
					if (car_arr[1].home_flag == 1)
						car_arr[1].home_flag = 2; // ������ ������ ����
					else
						car_arr[1].home_flag = 1;
				}
				else if (strcmp(topic, "sensor/2/1") == 0)
					Change_Lane(1, LEFT);
				else if (strcmp(topic, "sensor/2/2") == 0)
					Change_Lane(1, RIGHT);
				else if (strcmp(topic, "sensor/2/gyro") == 0)
					car_arr[1].battery = 0;
			}
		}
		
		//mqtt_publish(&broker, "moon", "hi234", 0);

		printf("===========================================\n");

	}
	return 0;
}
